// TO INCLUDE THIS FILE IN THE MAKEFILE AND OTHER PLACES TOO
#include "types.h"
#include "defs.h"
#include "param.h"
#include "fs.h"
#include "mmu.h"
#include "memlayout.h"
#include "proc.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "buf.h"
#include "x86.h"

struct swap_slot swap_space[NSWAP];

void
swapinit(void)
{
  int i;
  for(i = 0; i < NSWAP; i++)
  {
    swap_space[i].is_free = 1;
    swap_space[i].page_perm = 0;
  }
}

struct run* swap_out(struct proc *p, pte_t* pgtable_entry)
{
  int i;
  p->rss -= PGSIZE;
  for(i = 0; i < NSWAP; i++)
  {
    // swap out the page from the memory to the swap space
    // return the struct run* value pointing out to the old memory location of the swapped out page
    if(swap_space[i].is_free == 1)
    {
      swap_space[i].is_free = 0;
      swap_space[i].page_perm = PTE_FLAGS(*(pgtable_entry));
      struct run *page = (struct run*) P2V(PTE_ADDR(*(pgtable_entry)));
      for(int j = 0; j < 8; j++)
      {
        // read the page from the memory to the disk
        struct buf *b = bread(ROOTDEV, 8*i + SWAPSTART + j);
        memmove(b->data, P2V(PTE_ADDR(*(pgtable_entry))) + j*512, 512);
        bwrite(b);
        brelse(b);
      }
      *(pgtable_entry) = (((8*i + SWAPSTART) << 12) | (swap_space[i].page_perm)) & ~PTE_P;
      return page;
    }
  }
  return 0;
}

void swap_in()
{
    // find the starting disk block id of the swapped page from the page table entry
    uint fault_va = rcr2();
    struct proc *p = myproc();
    pte_t *pgtable_entry = walkpgdir(p->pgdir, (void*)fault_va, 0);
    uint swap_block_id = PTE_ADDR(*pgtable_entry) >> 12;
    // swap in the page
  // get the page permissions from the struct swap_slot corresponding to the swap_block_id
    uint page_perm = swap_space[(swap_block_id - SWAPSTART)/8].page_perm;
    // allocate a memory page using kalloc()
    char *mem_page = kalloc();
    // copy data from disk to memory
    for (int i = 0; i < 8; i++) {
      struct buf *b = bread(ROOTDEV, swap_block_id + i);
      memmove((mem_page + i*512), b->data, 512);
      brelse(b);
    }
    // restore the page premissions from the corresponding swap_slot.page_perm
    // update the page table entry of the swapped-in page
    *pgtable_entry = V2P(mem_page) | page_perm | PTE_P;
    swap_space[(swap_block_id - SWAPSTART)/8].is_free = 1;
    p->rss+=PGSIZE;
}

void free_swap(struct proc* p)
{
  for(int i = 0; i < p->sz; i+=PGSIZE)
  {
    pte_t *pgtable_entry = walkpgdir(p->pgdir, (void*)i, 0);
    if(pgtable_entry && ((*pgtable_entry & PTE_P) == 0))
    {
      uint swap_block_id = PTE_ADDR(*pgtable_entry) >> 12;
      swap_space[(swap_block_id - SWAPSTART)/8].is_free = 1;
    }
  }
}

void print_slots()
{
  for(int i = 0; i < NSWAP; i++)
  {
    cprintf("swap_space[%d].is_free = %d\n",i,swap_space[i].is_free);
  }
}